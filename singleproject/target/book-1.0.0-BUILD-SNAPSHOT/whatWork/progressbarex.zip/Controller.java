import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUpload;
import org.apache.commons.fileupload.ProgressListener;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;

@Controller
@RequestMapping("/")
public class Controller {
	//Apache Common FileUpload���
	@RequestMapping("/fileupload.do")
	public ModelAndView uploadData(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception{
		String serverFileName = "";
		String serverFileKeyVal = "";
		String fileSize = "";
		
		HashMap<String, String> strMap = new HashMap<String, String>();
		// Check that we have a file upload request
		boolean isMultipart = ServletFileUpload.isMultipartContent(request);
		if( isMultipart ) {
		    File temporaryDir = new File("C:\\TEMP");
		    // Create a factory for disk-based file items
		    DiskFileItemFactory factory = new DiskFileItemFactory();
		    // Set factory constraints
		    factory.setSizeThreshold(1024*100);
		    factory.setRepository(temporaryDir);
		    // Create a new file upload handler
		    ServletFileUpload upload = new ServletFileUpload(factory);
		    // Set overall request size constraint
		    upload.setSizeMax(1000*1024*1024);
		    
		    UploadProgressListener progressListener = new UploadProgressListener();
		    //������ ������ �Ѱܼ� ����������..
		    progressListener.setHttpSession(session);
		    //���α׷��� �����ʸ� ���Ͼ��ε�� �߰��Ѵ�.
		    upload.setProgressListener(progressListener);		    
		    
		    // Parse the request
		    List /* FileItem */ items = upload.parseRequest(request);
		    
		    // Process the uploaded items
		    Iterator iter = items.iterator();
		    while (iter.hasNext()) {
		        FileItem fileItem = (FileItem) iter.next();
		        if (fileItem.isFormField()) {
		            //multipart�� �Ѿ�� �� �ʵ��� �Ϲ� �Ķ���͵�
		        } else {				
		        	try{
		        		File uploadedFile = new File("C:\\TEMP", fileItem.getName());
		        		fileItem.write(uploadedFile);		        				        	
		        	}catch(IOException ioe){
		        		System.out.println(ioe);
		        	}
		        }
		    }
		} else {
		    System.out.println("���ڵ� Ÿ���� multipart/form-data �� �ƴ�.");
		    //enctype�� multipart�� �ƴҶ� ó�� �� �ټ� �ִ� �κ�(request.getParameter()ó��)
		}

		ModelAndView mav = new ModelAndView();
		mav.setViewName("progressbardemo");	//progressbardemo.jsp
		return mav;
	}
	
	//���Ͼ��ε� ���¸� �����´�.
	@RequestMapping("/uploadstatus.do")
	public ModelAndView getFileUploadStatus(HttpServletRequest request, HttpServletResponse response, HttpSession session){
		UploadProgressListener progressListener = new UploadProgressListener();
		session = progressListener.getHttpSession();		
		ModelAndView mav = new ModelAndView();
		mav.setViewName("upstatus");	
		return mav;
	}
}